# Wiki Index

**Last updated**: 2025-07-16 (third update: PCMag review re-cleaned, firmware-history page added)

---

## Sources

| Source | Summary | Reference text |
|---|---|---|
| [[source-summary/gt-ac5300-manual]] | ASUS ROG Rapture GT-AC5300 user manual (E12817, May 2017) — structured overview | [[source-summary/gt-ac5300-manual-text\|full extracted text]] |
| [[source-summary/gt-ac5300-pcmag-review]] | PCMag Editors' Choice review by John R. Delaney, 2018-08-31 — adds benchmarks + features not in manual | [[source-summary/gt-ac5300-pcmag-review-original\|verbatim clipping]] |
| [[source-summary/gt-ac5300-firmware-history]] | ASUS firmware history (2021+ confirmed; pre-2021 gaps noted). GT-AC5300 marked end-of-life by ASUS as of 2025-03-12. | (no verbatim — live source: [https://www.asus.com/supportonly/gt-ac5300/helpdesk_bios/](https://www.asus.com/supportonly/gt-ac5300/helpdesk_bios/)) |

Raw sources:
- [[../raw/E12817_GT_AC5300_Manual.pdf]]
- [[../raw/Asus ROG Rapture GT-AC5300 Review.md]]

## Entities

- [[entities/rog-rapture-gt-ac5300]] — ASUS ROG Rapture GT-AC5300 router

## Concepts

### Setup & GUI
- [[concepts/quick-internet-setup]] — QIS first-run wizard (modes incl. AiMesh)
- [[concepts/rog-gaming-center]] — Web GUI / dashboard
- [[concepts/aimesh]] — Mesh-controller operation mode (newer firmware)

### Gaming features (ROG-specific)
- [[concepts/game-ips]] — Trend-Micro network protection + parental controls
- [[concepts/game-boost]] — One-click gaming QoS (PS/Wii/3DS/Xbox prioritization)
- [[concepts/game-private-network]] — WTFast GPN integration
- [[concepts/game-profile]] — Curated port-forwarding per game
- [[concepts/game-radar]] — Per-game server ping tool
- [[concepts/wifi-radar]] — Wireless troubleshooting tool

### Wireless & networking
- [[concepts/wireless-settings]] — All wireless configuration (WPS, Bridge, MAC Filter, RADIUS, Professional)
- [[concepts/guest-network]] — Up to 9 isolated SSIDs
- [[concepts/smart-connect]] — Automatic tri-band steering
- [[concepts/lan-wan]] — LAN / WAN / Dual WAN / DMZ / DDNS
- [[concepts/port-forwarding-and-trigger]] — Static vs. dynamic port exposure
- [[concepts/vpn]] — Built-in PPTP VPN server
- [[concepts/vpn-fusion]] — VPN client + direct-internet split (newer firmware)

### Services & storage
- [[concepts/usb-applications]] — AiDisk, Servers Center, 3G/4G
- [[concepts/aicloud]] — ASUS AiCloud 2.0
- [[concepts/firewall]] — URL / Keyword / Network Services filters + IPv6 firewall

### System, automation & support
- [[concepts/administration]] — Operation mode, system, firmware, restore/save
- [[concepts/utilities]] — Device Discovery, Firmware Restoration, Printer Server, Download Master
- [[concepts/troubleshooting]] — Basic steps and FAQs
- [[concepts/alexa-ifttt]] — Alexa voice + IFTTT automation (newer firmware)

## Comparisons

- [[comparison/gt-ac5300-vs-competitors]] — GT-AC5300 vs XR500 / DIR-895L/R / R9000 / WRT32X (PCMag, 2018)
