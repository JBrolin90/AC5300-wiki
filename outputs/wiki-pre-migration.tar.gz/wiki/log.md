# Wiki Log

Append-only operation log.

---

## 2025-07-16 — Ingest: PCMag review of GT-AC5300

**Source**: `raw/Asus ROG Rapture GT-AC5300 Review.md` (Obsidian-style clipping, ~15 KB)
**Reviewer**: John R. Delaney (PCMag Contributing Editor), 2018-08-31. Editors' Choice (4.5/5).
**Copied to**: `wiki/source-summary/gt-ac5300-pcmag-review-original.md`

**Created pages**:
- `wiki/source-summary/gt-ac5300-pcmag-review.md` — structured summary of the review
- `wiki/concepts/vpn-fusion.md` — VPN + direct-internet split (new firmware feature, not in May-2017 manual)
- `wiki/concepts/aimesh.md` — mesh-controller operation mode
- `wiki/concepts/alexa-ifttt.md` — Alexa voice + IFTTT automation integration
- `wiki/comparison/gt-ac5300-vs-competitors.md` — 2018 competitive snapshot (XR500, DIR-895L/R, R9000, WRT32X)

**Updated pages** (sources / cross-links extended; no contradiction superseded):
- `wiki/entities/rog-rapture-gt-ac5300.md` — added review sources, PCMag benchmarks table, Editors' Choice award, and pricing notes
- `wiki/concepts/game-boost.md` — added reviewer-cited console list (PS, Wii/3DS, Xbox One)
- `wiki/concepts/vpn.md` — added cross-link to the new [[vpn-fusion]] page
- `wiki/concepts/quick-internet-setup.md` — added full operation-mode list incl. AiMesh (review-verified)
- `wiki/index.md` — populated with new entries

**Confidence**: 0.7–0.85. Single-reviewer test rig, single source for new features.

**Open verification / known issues**:
- VPN Fusion, AiMesh and Alexa/IFTTT are **not** in the May-2017 manual; almost certainly post-launch firmware additions, but the review doesn't name the firmware version. Menu paths for these features are not documented in the review.
- "Fastest 5 GHz close-proximity throughput PCMag had tested" was true at 2018 mid-year — historical, no longer accurate.

---

## 2025-07-16 — Cleanup pass: removed price discrepancies + added firmware-history page

**User request**: "The price is no longer important. Please dig the ASUS release notes to find out about the missing features. The historical mark is fine."

**Source consulted**: `https://www.asus.com/supportonly/gt-ac5300/helpdesk_bios/` (via Jina reader). Sibling archives (Wayback, snbforums, GitHub raw) were unreachable from this environment.

**New page**:
- `wiki/source-summary/gt-ac5300-firmware-history.md` — confirmed ASUS firmware entries 2021–2025, end-of-life notice on 2025-03-12 (`3.0.0.4.386_51582`), Asuswrt-Merlin EoL notice on 2024-11-17, AiMesh 2.0 confirmed in `3.0.0.4.386.41793` (2021-01-26). Pre-2021 entries flagged `[needs verification]`.

**Updated pages**:
- `wiki/source-summary/gt-ac5300-pcmag-review.md` — removed price-discrepancy section (no longer important).
- `wiki/entities/rog-rapture-gt-ac5300.md` — removed price section; added End-of-life section pointing at the firmware-history page; added the firmware-history page to sources.
- `wiki/concepts/aimesh.md` — confirmed AiMesh v2 firmware (`3.0.0.4.386.41793`).
- `wiki/concepts/vpn-fusion.md` — added firmware-history source; refined confidence.
- `wiki/concepts/alexa-ifttt.md` — added firmware-history source; added a "Firmware introduction (inferred)" section.
- `wiki/index.md` — added firmware-history row to sources table.

**What I tried and confirmed-unavailable**:
- Wayback Machine (`web.archive.org`) — anonymous access blocked (rate limit / abuse signal).
- snbforums.com — HTTP 403 / `nginx` block.
- ASUS `/support/api/product/GetPDList` endpoint — 500 (server down).
- GitHub raw user-content (`RMerl/asuswrt-merlin.ng/...`) — anonymous access blocked.
- DuckDuckGo search backend — requires the `ddgs` Python package (not installed).
- Brave / Serper / Tavily search backends — no API key configured.

**What I confirmed but did not yet turn into wiki text**:
- The Asuswrt-Merlin 386.14 (20-July-2024) release entry explicitly says **"Wifi Radar was removed (unsupported by Wifi 7 devices, and security issues cited by Asus in their own recent releases)"** — relevant if anyone tries to use the [[../concepts/wifi-radar]] page for current-stock firmware.

---

## 2025-07-16 — DuckDuckGo-driven firmware history filling

**User request**: "DuckDuckGo should be available now" — fill in the firmware introduction dates flagged `[needs verification]` in previous ingestion.

**Setup**: `pip3 install --break-system-packages ddgs` → `ddgs 9.14.4` installed; `web_search` with `backend: duckduckgo` now operational.

**Searches run** (DuckDuckGo):
- `"ASUS GT-AC5300 "VPN Fusion" firmware version added introduced"`
- `ASUS RT-AC5300 AiMesh added firmware 384 release notes`
- `ASUSWRT "Amazon Alexa" router skill firmware "3.0.0.4" release`
- `ASUSWRT IFTTT router firmware version released ROG`
- `"3.0.0.4.384.45149" GT-AC5300 release date 2020`
- `GT-AC5300 AiMesh "3.0.0.4.384.2" release notes 2018`
- `"3.0.0.4.384.10007" AiMesh ROG GT-AC5300 ASUS official release`
- `ASUS GT-AC5300 "VPN Fusion" 2024 firmware launch march`
- `GT-AC5300 "Alexa" "IFTTT" first firmware "382" or "384" added`
- `"VPN Fusion" ASUS debut 2024 march firmware 3.0.0.4.386 rog`
- `ASUS RT-AC5300 AiMesh "3.0.0.4.384.20287" 2018 "VPN Fusion" or "OpenVPN"`
- `RT-AC5300 GT-AC5300 "VPN Fusion" "3.0.0.4.384" introduction ROG only`
- `ASUS ROG GT-AC5300 firmware "382" "384" 2017 new feature "Alexa"`

**Confirmed via web sources**:

| Feature | Firmware | Date | Source |
|---------|----------|------|--------|
| VPN Fusion (first appearance) | `3.0.0.4.382.15984` | 2017-08-25 | ROG forum user testing sequence (Aimesh+20308 thread) |
| AiMesh v1 | `3.0.0.4.384.20287` | 2018-01-26 | SNBForums "AiMesh for Tri-band routers" thread |
| VPN Fusion functional build | `3.0.0.4.384.20648` | ~2018 mid | ROG forum March-2024 user report |
| New Alexa + IFTTT actions | `3.0.0.4.384.45149` | 2018-12-05 | ASUS release note (verbatim), SNBForums |
| Alexa + IFTTT (initial 382-branch) | `3.0.0.4.382_xxxxx` | ~Aug 2017 | RMerlin SNBForums statement; CSDN mod-thread mention |
| AiMesh v2 | `3.0.0.4.386.41793` | 2021-01-26 | ASUS support page (from earlier session) |

**Updated pages**:
- `wiki/source-summary/gt-ac5300-firmware-history.md` — complete rewrite of "Unverified" section, new "Feature introduction timeline" table, updated Summary/Confidence.
- `wiki/concepts/aimesh.md` — replaced `[needs verification]` for v1 with confirmed firmware + date.
- `wiki/concepts/vpn-fusion.md` — replaced `[needs verification]` with confirmed first-appearance firmware; added context on ROG-only exclusivity and the 20648 regression.
- `wiki/concepts/alexa-ifttt.md` — split into "first appearance" (~Aug 2017) and "second wave" (`3.0.0.4.384_45149`, 2018-12-05); removed `[needs verification]` for "Required firmware version".

**Remaining truly-unverifiable items**:
- Pre-2018 firmware dates more granular than "Aug 2017" (early 382 branch).
- Exact GUI menu path for VPN Fusion / Alexa on the modern firmware.
- Current live status of the Alexa skill and IFTTT service (cloud services change over time).

---

## 2025-07-16 — Q&A-derived wiki content: "AiMesh v2 vs v1" section

**Trigger**: User asked "What are the main benefit with AiMesh V2 compared to earlier versions?" and then "Would you use this answer as input for the wiki to improve it?"

**Action**: Restructured the chat-answer into a wiki-friendly table added to `wiki/concepts/aimesh.md` under the heading "AiMesh v2 vs v1 — what changed". Includes the eight specific improvements (Ethernet backhaul, one-click topology optimization, client-AP binding, client reconnect, guest WiFi on every node, USB access from nodes, new mobile app interface, Blue Cave as node), with attribution to the ASUS release note for `3.0.0.4.386.41793` and ASUS FAQ 1044184 / 1044151.

**Why**: Previous version of the page listed v2 only as a parenthetical mention ("ethernet backhaul, client-binding per AP, guest WiFi on all nodes, USB-from-nodes, blue-cave-into-AC5300 support"). The user Q+A surfaced a clean per-improvement organisation that the page was missing.

---

## 2025-07-16 — Initial ingest: ASUS ROG Rapture GT-AC5300 manual

**Source**: `raw/E12817_GT_AC5300_Manual.pdf` (152 pages, text layer present)
**Extracted to**: `wiki/source-summary/gt-ac5300-manual-text.txt` via `pdftotext -layout`

**Created pages**:
- `wiki/source-summary/gt-ac5300-manual.md` — structured manual summary
- `wiki/source-summary/gt-ac5300-manual-text.txt` — full extracted text (reference)
- `wiki/entities/rog-rapture-gt-ac5300.md` — device entity page
- `wiki/concepts/quick-internet-setup.md`
- `wiki/concepts/rog-gaming-center.md`
- `wiki/concepts/game-ips.md`
- `wiki/concepts/game-boost.md`
- `wiki/concepts/game-private-network.md`
- `wiki/concepts/game-profile.md`
- `wiki/concepts/game-radar.md`
- `wiki/concepts/wifi-radar.md`
- `wiki/concepts/wireless-settings.md`
- `wiki/concepts/guest-network.md`
- `wiki/concepts/smart-connect.md`
- `wiki/concepts/lan-wan.md`
- `wiki/concepts/port-forwarding-and-trigger.md`
- `wiki/concepts/vpn.md`
- `wiki/concepts/ipv6.md`
- `wiki/concepts/usb-applications.md`
- `wiki/concepts/aicloud.md`
- `wiki/concepts/firewall.md`
- `wiki/concepts/administration.md`
- `wiki/concepts/utilities.md`
- `wiki/concepts/troubleshooting.md`
- `wiki/index.md` — populated

**Confidence**: 0.8–0.95 across pages (mostly 0.85–0.9; the source is a single vendor doc from 2017).

**Known issues / open verification**:
- Manual §1.3 calls Link Aggregation "802.11ad" — almost certainly a typo for 802.3ad. Flagged with `[needs verification]`.
- §3.9 only documents a PPTP VPN server. No mention of OpenVPN/WireGuard in the firmware; cannot confirm from this source.
- WiFi Radar and Smart Connect Rules cite Broadcom docs that aren't reproduced in the manual.
