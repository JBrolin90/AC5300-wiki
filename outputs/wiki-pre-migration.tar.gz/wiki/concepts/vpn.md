# VPN

**Summary**: Built-in PPTP VPN server on the GT-AC5300 with optional Samba support for VPN clients. (No OpenVPN / WireGuard in this firmware.)

**Sources**: [[../source-summary/gt-ac5300-manual]], [[../source-summary/gt-ac5300-pcmag-review]]

**Last updated**: 2025-07-16

**Confidence**: 0.85

**Related**: [[lan-wan#NAT Passthrough]], [[vpn-fusion]]

---

## Server mode

`General → VPN`

1. **Enable PPTP VPN Server**: ON
2. (Optional) **Advanced Settings** dropdown to configure:
   - Broadcast support
   - Authentication
   - MPPE Encryption
   - Client IP address range
3. **Network Place (Samba) Support**: Yes → VPN clients can also access Samba shares
4. Add username + password; click add
5. Apply

## Client mode (pass-through)

[[lan-wan#NAT Passthrough|NAT Passthrough]] handles inbound VPN sessions from LAN clients to an external VPN server:
- **PPTP Passthrough** — default ON
- **L2TP Passthrough** — default ON
- **IPsec Passthrough** — default ON
- **RTSP Passthrough** — default ON

Toggle under `Advanced Settings → WAN → NAT Passthrough`.

## Caveats

- Only PPTP is supported as a server (per the manual). For OpenVPN/WireGuard you'd need newer firmware or different firmware (e.g. Merlin) — [needs verification].
- MPPE encryption requires clients that support it.

## Related firmware feature

- [[vpn-fusion]] — newer firmware feature that lets the router run a VPN **client** alongside the normal WAN, so game traffic can bypass the VPN. Distinct from the PPTP **server** covered above.
