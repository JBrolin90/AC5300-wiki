# IPv6

**Summary**: IPv6 addressing support on the GT-AC5300. Connection-type-dependent options; configuration values come from the ISP.

**Sources**: [[../source-summary/gt-ac5300-manual]]

**Last updated**: 2025-07-16

**Confidence**: 0.8

**Related**: [[lan-wan]]

---

## Setup

`Advanced Settings → IPv6`

1. Pick **Connection Type** (options depend on what your ISP offers)
2. Enter IPv6 **LAN** and **DNS** settings
3. Apply

## Caveats

> Manual note: "This standard is not yet widely available. Contact your ISP if your Internet service supports IPv6."

The manual doesn't enumerate the specific connection-type options (they vary by firmware). ISP provides the actual values to plug in.

## See also

- [[firewall#IPv6 Firewall]] — IPv6-specific inbound-traffic rules (default blocks unsolicited inbound).
