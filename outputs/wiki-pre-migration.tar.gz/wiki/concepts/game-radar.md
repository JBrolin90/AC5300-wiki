# Game Radar

**Summary**: Built-in diagnostic that pings the per-game server list and reports latency, so you can pick the lowest-ping server before queuing.

**Sources**: [[../source-summary/gt-ac5300-manual]]

**Last updated**: 2025-07-16

**Confidence**: 0.85

**Related**: [[game-profile]], [[game-private-network]], [[game-boost]]

---

## How to use

1. `General → Game Radar`
2. Pick a game from the list
3. Read the **Ping Status** column for each server
4. Pick the lowest-ping server and queue there

## Reference latency bands

Per the manual's [[../source-summary/gt-ac5300-manual#Dashboard (§3.2)|Dashboard]] section:

| Ping | Quality |
|---|---|
| < 99 ms | Good |
| < 150 ms | Acceptable |
| > 150 ms | Hard to play smoothly |

Lower **ping deviation** is better — high deviation causes in-game "toggling" (rubber-banding).

## Use it with

- [[game-profile]] — once you know which server you want, set the port-forward profile for that game.
- [[game-private-network]] — if all servers are far/high-ping, GPN can route through WTFast's optimized paths.
