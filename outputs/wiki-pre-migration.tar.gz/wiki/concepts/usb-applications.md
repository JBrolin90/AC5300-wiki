# USB Applications

**Summary**: Everything you can do with the two USB ports on the GT-AC5300 — file sharing via AiDisk/Samba/FTP, media servers (DLNA + iTunes), printer sharing, and 3G/4G WAN.

**Sources**: [[../source-summary/gt-ac5300-manual]]

**Last updated**: 2025-07-16

**Confidence**: 0.9

**Related**: [[aicloud]], [[lan-wan]]

---

## Supported devices

- USB HDDs / flash drives up to **4 TB**
- Filesystems: **FAT16, FAT32, NTFS, HFS+** (read-write)
- USB printer (one printer + one drive, OR two drives)
- 3G/4G USB modem (verify support at `http://event.asus.com/2009/networks/3gsupport/`)

## AiDisk

`Advanced Settings → USB application → AiDisk`

1. Click **Go** in the AiDisk wizard
2. Pick access rights (admin / user / limited)
3. Configure ASUS DDNS (`xxx.asuscomm.com`) — or **Skip**
4. Finish
5. Access via `ftp://<domain>.asuscomm.com`

## Servers Center

`Advanced Settings → USB application → Media Services and Servers`

### Media Server
- iTunes Server toggle
- DLNA Media Server toggle
- Status display
- Path: All Disks Shared **or** Manual path

### Samba (Network Place) Share
Default-enabled. Add accounts (name + password), add folders, set per-folder permission: **R/W / R / No**.

### FTP Share
- Assumes AiDisk already created the FTP server
- Per-folder rights: **R/W / W / R / No**
- Optional anonymous login (ON/OFF)
- **Max concurrent connections** field

## Safely removing the USB disk

`General → Network Map` → upper-right `>` → **Eject USB disk**. Status becomes "Unmounted" when safe. **Don't just unplug** — risk of data corruption.

## 3G/4G

`Advanced Settings → USB application → 3G/4G`

| Field | Value |
|---|---|
| Enable USB Modem | Yes |
| Location | ISP's country |
| ISP | Provider name |
| APN | (optional, from provider) |
| Dial Number | Access number |
| PIN code | From provider |
| Username / Password | From provider |
| USB Adapter | Specific model or **Auto** |

> After Apply, **the router reboots**.

## Printer Server

See [[utilities#Printer Server (EZ + LPR)]].
