# GT-AC5300 — ASUS firmware history (retrieved 2025-07-16)

**Summary**: Confirmed-as-of-this-ingest slice of the ASUS firmware release history for the ROG Rapture GT-AC5300. Confirms EoL status (2025-03-12) and pins down the introduction dates of every feature missing from the May-2017 user manual: VPN Fusion (~Aug 2017), Alexa + IFTTT (~Aug 2017, first 382-branch), AiMesh v1 (Jan 2018), and the second wave of Alexa + IFTTT actions (Dec 2018).

**Sources**:
- [[https://www.asus.com/supportonly/gt-ac5300/helpdesk_bios/]] (ASUS support page, retrieved 2025-07-16)
- [https://rog-forum.asus.com/t5/gaming-routers/rog-rapture-gt-ac5300-firmware-3-0-0-4-384-20308-with-aimesh-and/td-p/758225] (ROG forum thread with user firmware testing list)
- [https://www.snbforums.com/threads/aimesh-for-tri-band-routers-rt-ac5300-gt-ac5300.44023/] (SNBForums AiMesh discussion, dated Jan 2018)
- [https://www.snbforums.com/threads/is-there-any-news-of-ifttt-compliance-in-asus-merlin-firmware-for-rt-68u.40525/] (RMerlin himself noting Alexa+IFTTT are 382-branch-only)

**Last updated**: 2025-07-16

**Confidence**: 0.85 for the 2017–2018 milestones (corroborated across ROG forum + SNBForums user testing sequences); 0.9 for the 2021+ entries (direct ASUS source).

---

## Status: End-of-life

The latest published firmware (3.0.0.4.386_51582, 2025-03-12) ships with the following notice verbatim from ASUS:

> "This model was end of its life, and its firmware, utility, website, and manual will no longer be updated."

Reference link cited on the firmware page: https://www.asus.com/event/network/eol-product/

Implication for this wiki: no further ASUS-provided versions will appear. Third-party firmware (Asuswrt-Merlin) likewise dropped the 386.xx branch after 386.14_2 (17-Nov-2024, see [[../comparison/asuswrt-merlin-386-eol]] note below).

## Feature introduction timeline (compiled from ROG forum + SNBForums)

| Date | Firmware | Event | Confidence |
|------|----------|-------|-----------|
| 2017-06-09 | `3.0.0.4.382.12184` | Launch-era firmware: OpenVPN works, **no VPN Fusion** option. | direct user testing |
| 2017-08-25 | `3.0.0.4.382.15984` | **VPN Fusion** option added to GUI; Alexa code base present (disabled in China region). | direct user testing |
| 2018-01-26 | `3.0.0.4.384.20287` | **AiMesh v1** introduced ("an innovative new router feature that connects multiple ASUS routers to create a whole-home Wi-Fi network"). | direct forum notes |
| ~2018 mid | `3.0.0.4.384.20648` | VPN Fusion functional in this build (regressed in later versions; recovered eventually). | single user report |
| 2018-12-05 | `3.0.0.4.384.45149` | **New Alexa skills + new IFTTT actions** added: "ask ASUS ROUTER to report security status", "how many devices online"; IFTTT: Wake on LAN, "check new firmware and upgrade". Same firmware also adds Lyra-series support as AiMesh nodes for GT-AC5300. | ASUS release note verbatim |
| 2021-01-26 | `3.0.0.4.386.41793` | **AiMesh v2**: ethernet backhaul, client-binding per AP, guest WiFi on all nodes, USB access from nodes, support for adding BlueCave as a mesh node. New Family interface in ASUS Router mobile app. | direct ASUS release note |
| 2021-05-07 | `3.0.0.4.386.42643` | CVE fixes; FragAttacks fix. | direct |
| 2022-03-17 | `3.0.0.4.386.46092` | Multiple CVE fixes; AiMesh guest network fix; IPSec VPN fix; DDNS IPv6 fix. | direct |
| 2022-03-30 | `3.0.0.4.386.48377` | OpenSSL CVE-2022-0778; Stored XSS fix; 3rd-party DNS server list in WAN → DNS. | direct |
| 2023-11-27 | `3.0.0.4.386.51529` | DoS + httpd fixes; null-pointer-deref fixes; CVE-2023-28702/28703. | direct |
| 2024-11-12 | `3.0.0.4.386.51569` | Input validation, AiCloud password protection, cert/buffer hardening. | direct |
| 2025-03-12 | `3.0.0.4.386.51582` | **End-of-life** notice alongside UI/Chrome fix and input-validation hardening. | direct |

## Confirmed entries (ASUS, supportonly/gt-ac5300/helpdesk_bios, retrieved 2025-07-16)

Listed newest → oldest in the order ASUS serves them. All entries are `3.0.0.4.386.x` firmware. SHA-256/MD5 checksums and download URLs are on the original ASUS page; this wiki does not duplicate them.

| Date | Version (file name suffix) | Notable change |
|------|---------------------------|----------------|
| 2025-03-12 | `3.0.0.4.386_51582` | EoL notice; UI/Chrome fix; input validation hardening |
| 2024-11-12 | `3.0.0.4.386_51569` | Input validation hardening; AiCloud password protection; cert/buffer/file-access hardening |
| 2023-11-27 | `3.0.0.4.386_51529` | DoS fixes (firewall + httpd); null-pointer-dereference fixes; CVE-2023-28702, CVE-2023-28703 |
| 2022-03-30 | `3.0.0.4.386.48377` | OpenSSL CVE-2022-0778; stored XSS fix (CVE Milan Kyselica of IstroSec); 3rd-party DNS server list in WAN → DNS |
| 2022-03-17 | `3.0.0.4.386.46092` | Multiple CVE fixes (CVE-2021-34174, 2022-23970/1/2/3, 2022-23973, 2022-25595/6); AiMesh guest network fix; IPSec VPN fix; DDNS IPv6 fix; UI bugfixes |
| 2021-05-07 | `3.0.0.4.386.42643` | CVE-2021-3450 / CVE-2021-3449 (OpenSSL); FragAttacks |
| 2021-02-03 | `9.0.0.4.386.41994` (beta) | DNSmasq CVE-2020-25681..25687 quick-fix beta |
| 2021-01-26 | `3.0.0.4.386.41793` | **AiMesh 2.0**: ethernet backhaul, client-binding per AP, guest WiFi on all nodes, USB access from nodes; new ASUS Router Family interface in mobile app |

Versions older than `3.0.0.4.386.41793` are not currently published on the ASUS support page (the dynamic list stops at that entry), and the Wayback Machine / snbforums / GitHub archives were unreachable from this environment on the date of retrieval.

## Confirmed via Asuswrt-Merlin changelog (not ASUS)

From `asuswrt-merlin.net/changelog-386` and `changelog-380`, the GT-AC5300 (Merlin models it as "RT-AC5300") lifecycle:

- **Merlin 386.14_2** (17-Nov-2024) — final 386.xx release. Security backports only.
- **Merlin 386.14** (20-July-2024) — merged with ASUS GPL `386_52805`. **Wifi Radar was removed** (citing Asus's own security concerns). **Reminder**: all 386.xx models stopped at the end of 2024.
- **Merlin 386.7** (22-June-2022) — merged with ASUS GPL `386_49335` specifically for the RT-AC5300.

(Only the 386.xx branch applies to the GT-AC5300; the 380.xx branch is for older hardware.)

## Resolved open verifications (as of this session)

| Feature | Page | Confirmed |
|---|---|---|
| VPN Fusion (stock-ASUS) | [[../concepts/vpn-fusion]] | First appearance in GUI: firmware **`3.0.0.4.382.15984`** (~Aug 2017). ROG-only until 388_2xxxx. |
| AiMesh v1 | [[../concepts/aimesh]] | Firmware **`3.0.0.4.384.20287`** (2018-01-26). v2 in `3.0.0.4.386.41793` (2021-01-26). |
| Alexa + IFTTT (initial) | [[../concepts/alexa-ifttt]] | 382 branch (~Aug 2017). (RMerlin statement.) |
| Alexa + IFTTT (second wave) | [[../concepts/alexa-ifttt]] | Firmware **`3.0.0.4.384_45149`** (2018-12-05): added "report security status", "how many devices online", Wake on LAN, "check new firmware". |

## Notes for future re-ingest

- The Wayback Machine (`web.archive.org`) was blocked from this environment on 2025-07-16 — unblocked in this session only on DuckDuckGo via the `ddgs` Python package.
- The Merlin-incompatibility statements (RMerlin himself on SNBForums) are useful corroboration for stock-firmware feature boundary dates.
- For pre-2018 firmware (`3.0.0.4.382.xxxxx`), the ROG forum (rog-forum.asus.com) houses per-release discussion threads with verbatim release notes — often the most detailed record because the ASUS support page retroactively removes them.
